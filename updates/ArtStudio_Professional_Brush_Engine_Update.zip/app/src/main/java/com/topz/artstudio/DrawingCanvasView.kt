package com.topz.artstudio

import android.content.Context
import android.graphics.*
import android.view.InputDevice
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.io.File
import java.io.FileOutputStream
import kotlin.math.min

class DrawingCanvasView(context: Context) : View(context) {
    private var bitmap = Bitmap.createBitmap(1600, 1600, Bitmap.Config.ARGB_8888)
    private var canvasBitmap = Canvas(bitmap)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 12f
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val undo = ArrayDeque<Bitmap>()
    private val redo = ArrayDeque<Bitmap>()
    private var drawing = false
    private var eraser = false
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var brushSize = 12f
    private var brushOpacity = 1f
    private var stabilization = 0.35f
    private var preset = "Brush"

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            scale = (scale * detector.scaleFactor).coerceIn(0.2f, 8f); invalidate(); return true
        }
    })

    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(55, 60, 70))
        val fit = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val s = fit * scale
        val left = (width - bitmap.width * s) / 2f + offsetX
        val top = (height - bitmap.height * s) / 2f + offsetY
        canvas.save(); canvas.translate(left, top); canvas.scale(s, s)
        canvas.drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), Paint().apply { color = Color.WHITE })
        canvas.drawBitmap(bitmap, 0f, 0f, null)
        canvas.restore()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (event.pointerCount > 1) return true
        val fit = min(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val s = fit * scale
        if (s <= 0f) return true
        val left = (width - bitmap.width * s) / 2f + offsetX
        val top = (height - bitmap.height * s) / 2f + offsetY
        val x = (event.x - left) / s
        val y = (event.y - top) / s
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (x !in 0f..bitmap.width.toFloat() || y !in 0f..bitmap.height.toFloat()) return true
                pushUndo(); redo.clear(); path.reset(); path.moveTo(x, y)
                lastX = x; lastY = y; drawing = true
                drawDab(x, y, pressure(event))
                return true
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                val factor = 1f - stabilization * 0.85f
                val sx = lastX + (x - lastX) * factor
                val sy = lastY + (y - lastY) * factor
                path.quadTo(lastX, lastY, (sx + lastX) / 2f, (sy + lastY) / 2f)
                lastX = sx; lastY = sy
                applyPaint(pressure(event))
                if (preset == "Airbrush" && !eraser) {
                    val air = Paint(paint).apply { style = Paint.Style.STROKE; maskFilter = BlurMaskFilter(brushSize * 1.5f, BlurMaskFilter.Blur.NORMAL) }
                    canvasBitmap.drawPath(path, air)
                } else canvasBitmap.drawPath(path, paint)
                path.reset(); path.moveTo(lastX, lastY); invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (drawing) { applyPaint(pressure(event)); canvasBitmap.drawPath(path, paint); path.reset() }
                drawing = false; invalidate(); return true
            }
        }
        return true
    }

    private fun pressure(event: MotionEvent): Float {
        val device: InputDevice? = event.device
        val hasPressure = device?.getMotionRange(MotionEvent.AXIS_PRESSURE) != null
        return if (hasPressure) event.pressure.coerceIn(0.15f, 1f) else 1f
    }

    private fun drawDab(x: Float, y: Float, p: Float) {
        applyPaint(p)
        if (preset == "Airbrush" && !eraser) {
            val dab = Paint(paint).apply { style = Paint.Style.FILL; maskFilter = BlurMaskFilter(brushSize * 1.5f, BlurMaskFilter.Blur.NORMAL) }
            canvasBitmap.drawCircle(x, y, brushSize, dab)
        } else canvasBitmap.drawPoint(x, y, paint)
        invalidate()
    }

    private fun applyPaint(pressure: Float) {
        paint.xfermode = if (eraser) PorterDuffXfermode(PorterDuff.Mode.CLEAR) else null
        paint.maskFilter = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = when (preset) {
            "Pencil" -> brushSize * 0.72f
            "Ink" -> brushSize * (0.65f + pressure * 0.7f)
            "Airbrush" -> brushSize * 1.6f
            else -> brushSize
        }
        var alpha = brushOpacity
        if (preset == "Pencil") alpha *= 0.72f
        if (preset == "Airbrush") {
            alpha *= 0.16f
            paint.maskFilter = BlurMaskFilter(brushSize * 1.2f, BlurMaskFilter.Blur.NORMAL)
        }
        paint.alpha = (255 * alpha).toInt().coerceIn(1, 255)
    }

    private fun snapshot() = bitmap.copy(Bitmap.Config.ARGB_8888, true)
    private fun pushUndo() { if (undo.size >= 15) undo.removeFirst(); undo.addLast(snapshot()) }

    fun undo() {
        if (undo.isNotEmpty()) { redo.addLast(snapshot()); bitmap = undo.removeLast(); canvasBitmap = Canvas(bitmap); invalidate() }
    }
    fun redo() {
        if (redo.isNotEmpty()) { pushUndo(); bitmap = redo.removeLast(); canvasBitmap = Canvas(bitmap); invalidate() }
    }
    fun setColor(color: Int) { eraser = false; paint.color = color; paint.xfermode = null }
    fun setEraser(enabled: Boolean) { eraser = enabled; applyPaint(1f) }
    fun setBrushPreset(name: String) { preset = name; eraser = false; applyPaint(1f) }
    fun setBrushSize(size: Float) { brushSize = size.coerceIn(1f, 120f); applyPaint(1f) }
    fun setBrushOpacity(opacity: Float) { brushOpacity = opacity.coerceIn(0.01f, 1f); applyPaint(1f) }
    fun setStabilization(amount: Float) { stabilization = amount.coerceIn(0f, 0.9f) }

    fun clearCanvas() { pushUndo(); redo.clear(); bitmap.eraseColor(Color.TRANSPARENT); invalidate() }
    fun loadImage(file: File) {
        BitmapFactory.decodeFile(file.absolutePath)?.let { bitmap = it.copy(Bitmap.Config.ARGB_8888, true); canvasBitmap = Canvas(bitmap); invalidate() }
    }
    fun saveImage(file: File) {
        file.parentFile?.mkdirs()
        FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
