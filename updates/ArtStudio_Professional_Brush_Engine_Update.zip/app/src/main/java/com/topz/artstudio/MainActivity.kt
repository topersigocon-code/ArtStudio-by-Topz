package com.topz.artstudio

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var canvasView: DrawingCanvasView? = null
    private var currentFile: File? = null
    private val bg = Color.rgb(18, 22, 32)
    private val panel = Color.rgb(29, 36, 50)
    private val gold = Color.rgb(238, 184, 67)
    private val ink = Color.rgb(242, 244, 248)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); showGallery() }

    private fun baseLayout(title: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        root.addView(TextView(this).apply {
            text = title; textSize = 19f; setTextColor(gold); gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 10, 16, 10); setBackgroundColor(panel); maxLines = 1
        }, LinearLayout.LayoutParams(-1, 52))
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        return content
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; minWidth = 0; minimumWidth = 0
        setPadding(6, 0, 6, 0); setTextColor(ink); setBackgroundColor(Color.rgb(48, 58, 76))
        setOnClickListener { action() }
    }

    private fun addToolbar(parent: LinearLayout, items: List<Pair<String, () -> Unit>>) {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(panel) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        items.forEach { (label, action) ->
            row.addView(makeButton(label, action), LinearLayout.LayoutParams(76, 44).apply { setMargins(3, 0, 3, 0) })
        }
        scroll.addView(row)
        parent.addView(scroll, LinearLayout.LayoutParams(-1, 48))
    }

    private fun showGallery() {
        canvasView = null
        val body = baseLayout("ArtStudio by Topz")
        body.addView(TextView(this).apply {
            text = "Your offline creative studio"; textSize = 14f; setTextColor(ink); setPadding(18, 18, 18, 8)
        })
        body.addView(makeButton("＋  Create New Canvas") { openCanvas(null) },
            LinearLayout.LayoutParams(-1, 58).apply { setMargins(16, 10, 16, 16) })
        val files = artworkFiles()
        if (files.isEmpty()) {
            body.addView(TextView(this).apply {
                text = "No artwork yet. Create a canvas to start drawing."; setTextColor(Color.LTGRAY)
                gravity = Gravity.CENTER; textSize = 15f
            }, LinearLayout.LayoutParams(-1, 0, 1f))
        } else files.sortedByDescending { it.lastModified() }.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(14, 8, 14, 8); setBackgroundColor(panel)
            }
            row.addView(TextView(this).apply {
                text = file.nameWithoutExtension; textSize = 16f; setTextColor(ink); setPadding(8, 8, 8, 8)
            }, LinearLayout.LayoutParams(0, 52, 1f))
            row.addView(makeButton("Open") { openCanvas(file) })
            body.addView(row, LinearLayout.LayoutParams(-1, 64).apply { setMargins(12, 4, 12, 4) })
        }
    }

    private fun openCanvas(file: File?) {
        currentFile = file
        val body = baseLayout("ArtStudio  •  ${file?.nameWithoutExtension ?: "Untitled"}")
        val view = DrawingCanvasView(this)
        canvasView = view
        if (file != null && file.exists()) view.loadImage(file)
        body.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))

        addToolbar(body, listOf(
            "Brush" to { view.setEraser(false) }, "Erase" to { view.setEraser(true) },
            "Undo" to { view.undo() }, "Redo" to { view.redo() }, "Save" to { saveArtwork() },
            "Gallery" to { showGallery() }, "Clear" to { view.clearCanvas() }
        ))

        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(panel) }
        body.addView(presets, LinearLayout.LayoutParams(-1, 42))
        listOf("Brush", "Pencil", "Ink", "Airbrush").forEach { name ->
            presets.addView(makeButton(name) { view.setBrushPreset(name) },
                LinearLayout.LayoutParams(0, 40, 1f).apply { setMargins(2, 1, 2, 1) })
        }

        addSlider(body, "Size", 1, 120, 12) { view.setBrushSize(it.toFloat()) }
        addSlider(body, "Opacity", 1, 100, 100) { view.setBrushOpacity(it / 100f) }
        addSlider(body, "Stabilizer", 0, 90, 35) { view.setStabilization(it / 100f) }

        val colors = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(panel) }
        body.addView(colors, LinearLayout.LayoutParams(-1, 40))
        listOf(Color.BLACK, Color.WHITE, Color.RED, Color.BLUE, Color.GREEN, gold).forEach { color ->
            colors.addView(View(this).apply { setBackgroundColor(color); setOnClickListener { view.setColor(color) } },
                LinearLayout.LayoutParams(30, 30).apply { setMargins(8, 4, 8, 4) })
        }
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 0, 10, 0); setBackgroundColor(panel)
        }
        val title = TextView(this).apply { text = "$label $initial"; textSize = 11f; setTextColor(ink) }
        row.addView(title, LinearLayout.LayoutParams(82, -2))
        row.addView(SeekBar(this).apply {
            this.max = max - min; progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + min; title.text = "$label $value"; changed(value)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(0, 36, 1f))
        parent.addView(row, LinearLayout.LayoutParams(-1, 36))
    }

    private fun saveArtwork() {
        val view = canvasView ?: return
        try {
            val dir = File(filesDir, "artworks").apply { mkdirs() }
            val target = currentFile ?: File(dir, "Artwork_${System.currentTimeMillis()}.png")
            view.saveImage(target); currentFile = target
            Toast.makeText(this, "Artwork saved on this device", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun artworkFiles(): List<File> = File(filesDir, "artworks").listFiles()?.filter {
        it.isFile && it.extension.equals("png", true)
    } ?: emptyList()
}
